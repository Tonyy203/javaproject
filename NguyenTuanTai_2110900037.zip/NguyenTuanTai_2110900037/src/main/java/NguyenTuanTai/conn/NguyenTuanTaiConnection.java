package NguyenTuanTai.conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class NguyenTuanTaiConnection {
	public static void closeQuietly(Connection conn) {
		try {
			conn.close();
		}catch(Exception e) {
			
		}
	}
	public static void rollbackQuietly(Connection conn) {
		try {
			conn.rollback();
		}catch(Exception e) {
			
		}
	}
}
